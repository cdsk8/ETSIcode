#include "TestOrdenacion.h"
#include <iostream>
using namespace std;

/** Programa principal **/
int main()
{
	//** ESCRIBIR PARA COMPLETAR LA PRACTICA **//
	return 0;
};